/* Browser-free smoke tests; run with: node test.mjs */
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const src=fs.readFileSync(new URL('./app.js',import.meta.url),'utf-8');
const stub={app:{innerHTML:''},page:{innerHTML:''}};
const listeners={};const data={};
const ctx={document:{getElementById:(k)=>stub[k]||null,addEventListener:(k,fn)=>listeners[k]=fn},window:{scrollTo(){}},localStorage:{getItem:(k)=>data[k]||null,setItem:(k,v)=>data[k]=v},Intl,Date,Math,Number,Array,Object,String,JSON,Map,Set,URL,console,confirm:()=>true,setTimeout,clearTimeout};
vm.createContext(ctx);
const replaced=src.replace(/render\(\);\s*\}\)\(\);\s*$/,
 `window.__test={render,computePlans,state:()=>state,plans:()=>plans,changeView:v=>{view=v;render()},openModal,drawer:()=>drawerHtml(),quoteTotal,isApproved,saveModal}; render();\n})();`);
assert.notEqual(replaced,src);
vm.runInContext(replaced,ctx);
const t=ctx.window.__test;
for(const view of ['dashboard','projects','planner','production','clients','quotes','inventory','portal','settings']){
  t.changeView(view);assert.ok(stub.page.innerHTML.length>300,view+' did not render');
}
assert.equal(t.state().projects.length,4);
assert.ok(t.plans().p1);
assert.equal(t.isApproved(t.state().projects[0]),false);
const calc=t.quoteTotal({items:[{qty:80,unit:1.8}],discount:0});
assert.equal(calc.subtotal,144);
assert.equal(calc.vat,31.68);
for(const [view,name] of [['project','Crea un nuovo progetto'],['client','Aggiungi cliente'],['stock','Nuovo materiale'],['quote','Nuovo preventivo']]){
  t.openModal(view);assert.ok(stub.app.innerHTML.includes(name),view+' modal missing');
}
console.log('OK — 9 viste, 4 modali, pianificazione, gate approvazione e prezzi');
