# Evoluzione dalla V1 locale alla versione di produzione

## Step A — Fondamenta cloud e sicurezza
- Next.js + PostgreSQL (Supabase o backend equivalente), authentication email e MFA per studio; magic link a scadenza per clienti.
- Modello dati: users, team_members, clients, projects, workflow_templates, tasks, dependencies, quotes, quote_items, material_stock, files, file_versions, approvals, audit_events.
- Ruoli ADMIN / COLLABORATORE / CLIENTE. Policy a livello server e database; un cliente vede soltanto i suoi progetti e nessun costo o appunto interno.
- Backup automatici, migrazioni versionate, soft delete e retention GDPR; gestire nominativi invitati con attenzione.

## Step B — Pianificazione realmente automatica
- Vista settimanale per ciascun membro, disponibilità per fascia oraria e giorni specifici (es. Claudia 4 ore distribuite negli slot concordati).
- Capacità per macchina, dipendenze, lead time fornitore, fase di approvazione, buffer e impossibilità di procedere senza file finali.
- Integrazione Google Calendar tramite OAuth lato server; leggere free/busy, creare eventi solo sul calendario dedicato, conservare ID evento e fare sync idempotente.
- Planning a ritroso e simulazione delle tre date possibili quando una scadenza non è fattibile.
- Proporre ripianificazioni all'operatrice, senza sovrascrivere il calendario personale o informare i clienti automaticamente.

## Step C — Area cliente autentica
- Timeline condivisa, raccolta brief, versioni e anteprime numerate, upload file e note.
- Approvazione associata al file/versione e timestamp server; in caso di modifica successiva l'approvazione viene invalidata.
- Richieste di modifiche, quantità finali e conferma a saldo.

## Step D — Economia e produzione
- Listini distinti: costo industriale, solo produzione B2B, vendita privato, design, assemblaggio, spedizione.
- Preventivi PDF, acconti (predefinito 40%), saldo, scadenze e costi effettivi; calcolo margine con costo del tempo.
- Distinta materiali, quantità carta/buste, pianificazione lotti, QC e scarico magazzino automatico.

## Controlli prima della pubblicazione per clienti reali
Testare privacy, autenticazione/autorizzazioni, isolamento cliente A/B, carico simultaneo, backup/restore, gestione errori Calendar, edge case di scadenze, stampa da approvazioni, sicurezza allegati e mobile.
