# Sage Paper Design · Studio Manager — MVP v1.0

Una **nuova applicazione** per la gestione di Sage Paper Design, sviluppata da zero senza dipendenze JavaScript. Si può aprire il file `index.html` in locale o pubblicare questa cartella come sito statico su Vercel.

## Funzioni utilizzabili

- Dashboard con progetti attivi, consegne a rischio, carico stimato e preventivi.
- Progetti Wedding, B2B stampa/taglio, wedding website, shop/retail, design e altro.
- Creazione/modifica/eliminazione progetti e checklist con template personalizzati per tipologia.
- Gate di approvazione: non è possibile completare la fase di produzione senza approvazione finale.
- Pianificatore indicativo a ritroso dalle deadline, con ore per persona, buffer, lead time, giorni feriali e segnalazione conflitti.
- Clienti e anagrafiche di base.
- Preventivi con listino delle tariffe di *sola produzione* già concordate, righe personalizzate, sconto, IVA e acconto configurabili.
- Magazzino manuale con soglie minime di riordino.
- Simulazione di area cliente (NON condivisibile e NON autenticata).
- Impostazioni, backup JSON e ripristino.
- Layout responsive per desktop e smartphone.

## Avvio immediato

Aprire `index.html`. In alternativa:

```bash
python3 -m http.server 8000
```

quindi aprire `http://localhost:8000`.

## Pubblicazione su Vercel

Importare su Vercel una repository contenente `index.html`, `styles.css` e `app.js` nella root, oppure caricare la cartella come progetto statico. Nessuna build necessaria. **Non** sovrascrivere l'attuale sito senza averne prima esportato e salvato tutti i dati: questa è un'app distinta.

## Limitazioni importanti — leggere prima dell'uso professionale

1. **Archiviazione**: `localStorage` del browser. I dati NON vengono sincronizzati su altri dispositivi. Navigazione in incognito, reset o cancellazione dei dati del browser possono cancellarli. Esportare backup JSON regolarmente.
2. **Nessuna autenticazione**: non inserire dati sensibili o informazioni reali di clienti se il browser è condiviso. L'area cliente è solo una rappresentazione dimostrativa, non una funzione sicura pronta da pubblicare.
3. **Pianificazione**: usa giorni feriali, capacità nominale ripartita su 5 giorni, buffer e tempi standard. Non legge Google Calendar, ferie, vincoli di macchinario, materiali o disponibilità specifica per giorno. Gli avvisi sono indicativi e non equivalgono a conferma della fattibilità.
4. **Preventivi**: prezzi IVA esclusa di sola produzione, aliquota impostabile. Nessuna generazione automatica di PDF contrattuale, firma o incasso. Validare i prezzi prima dell'invio a un cliente.
5. **Approvazioni**: il flag di approvazione è locale e NON ha valore come approvazione legale verificata di un cliente, mancando autenticazione, timestamp verificabile e versioning file.
6. **Progetti demo**: i dati iniziali sono del tutto fittizi. È possibile creare i propri record ed esportare il backup.

## Architettura futura consigliata

Per la vera versione gestionale multiutente: frontend React/Next.js, database PostgreSQL, autenticazione e RLS per utenti e clienti, storage protetto e versioning documenti, API server per Google Calendar OAuth, audit log per le approvazioni, invio email, scheduler con calendario reale, preventivi PDF e gateway pagamenti. Migrare i dati JSON dopo definizione dello schema e test.

## Verifica rapida

Se Node.js è installato, eseguire `node test.mjs` nella cartella del progetto. La suite verifica il rendering delle nove sezioni, le quattro finestre di creazione, la pianificazione, i vincoli di approvazione e il calcolo del listino.

## File

- `index.html`: shell HTML e metadata.
- `styles.css`: tema responsive Sage Paper.
- `app.js`: stato, interfacce e logica di pianificazione.
- `test.mjs`: test di controllo senza dipendenze.

© Sage Paper Design — prototipo funzionale MVP.
